package com.example.bettracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private data class Bet(val id: Long, val stake: Double, val odds: Double, val result: String) {
    val payout: Double get() = if (result == "WIN") stake * odds else 0.0
    val profit: Double get() = payout - stake
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { BetTrackerApp() } }
}

@Composable fun BetTrackerApp() {
    var capital by remember { mutableStateOf(100000.0) }
    var bets by remember { mutableStateOf(listOf<Bet>()) }
    var showAdd by remember { mutableStateOf(false) }
    val totalStake = bets.sumOf { it.stake }
    val net = bets.sumOf { it.profit }
    val current = capital + net

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF16A34A), secondary = Color(0xFF0EA5E9))) {
        Scaffold(bottomBar = { NavigationBar { NavigationBarItem(true, {}, { }, label = { Text("Dashboard") }); NavigationBarItem(false, {}, { }, label = { Text("History") }) } },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }, containerColor = Color(0xFF16A34A), contentColor = Color.White) { Text("+") } }) { pad ->
            LazyColumn(modifier = Modifier.fillMaxSize().background(Color(0xFFF5F7FA)).padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Bet Tracker", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Simamia mtaji, bets na faida yako", color = Color.Gray) }
                item { Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) { Column(Modifier.padding(20.dp)) { Text("MTaji uliopo", color = Color.LightGray); Text(money(current), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(if (net >= 0) "+${money(net)} faida" else "${money(net)} hasara", color = if (net >= 0) Color(0xFF4ADE80) else Color(0xFFF87171), fontWeight = FontWeight.Bold) } } }
                item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) { Stat("Total Stake", money(totalStake), Modifier.weight(1f)); Stat("Faida/Hasara", money(net), Modifier.weight(1f)) } }
                item { Text("Historia ya bets", fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                if (bets.isEmpty()) item { Card { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("Bado hujaongeza bet yoyote."); Text("Bonyeza + kuanza", color = Color.Gray) } } }
                items(bets.reversed(), key = { it.id }) { b -> BetRow(b) }
                item { Spacer(Modifier.height(60.dp)) }
            }
        }
    }
    if (showAdd) AddBetDialog(onDismiss = { showAdd = false }) { stake, odds, result -> bets = bets + Bet(System.currentTimeMillis(), stake, odds, result); showAdd = false }
}

@Composable fun Stat(title: String, value: String, modifier: Modifier) { Card(modifier) { Column(Modifier.padding(14.dp)) { Text(title, color = Color.Gray, fontSize = 12.sp); Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp) } } }
@Composable fun BetRow(b: Bet) { Card { Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Stake ${money(b.stake)}", fontWeight = FontWeight.Bold); Text("Odds ${b.odds}") }; Column(horizontalAlignment = Alignment.End) { Text(b.result, color = if (b.result == "WIN") Color(0xFF16A34A) else Color(0xFFDC2626), fontWeight = FontWeight.Bold); Text(if (b.profit >= 0) "+${money(b.profit)}" else money(b.profit), color = if (b.profit >= 0) Color(0xFF16A34A) else Color(0xFFDC2626)) } } } }

@Composable fun AddBetDialog(onDismiss: () -> Unit, onSave: (Double, Double, String) -> Unit) {
    var stake by remember { mutableStateOf("") }; var odds by remember { mutableStateOf("") }; var result by remember { mutableStateOf("WIN") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Ongeza Bet") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(stake, { stake = it }, label = { Text("Stake (TSh)") }, singleLine = true); OutlinedTextField(odds, { odds = it }, label = { Text("Odds") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(result == "WIN", { result = "WIN" }, label = { Text("WIN") }); FilterChip(result == "LOSS", { result = "LOSS" }, label = { Text("LOSS") }) } } }, confirmButton = { Button(enabled = stake.toDoubleOrNull() != null && odds.toDoubleOrNull() != null, onClick = { onSave(stake.toDouble(), odds.toDouble(), result) }) { Text("Hifadhi") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Ghairi") } })
}
fun money(v: Double): String = NumberFormat.getNumberInstance(Locale.US).format(v) + " TSh"
